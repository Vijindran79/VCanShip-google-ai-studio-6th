// ⚠️  READ-ONLY — DO NOT EDIT — SERVICE LOCKED ⚠️
// This file is reserved for future localization data and features.